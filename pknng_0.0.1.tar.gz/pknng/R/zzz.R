#
#       Author: Ariel E. Baya <abaya@ifir.edu.ar>
#  Last Change: $Date: 2007/03/28 $
#
#      Package: pknng
#         File: zzz.R
#

.First.lib <- function(lib, pkg) {
  library.dynam("pknng", pkg, lib)
}
